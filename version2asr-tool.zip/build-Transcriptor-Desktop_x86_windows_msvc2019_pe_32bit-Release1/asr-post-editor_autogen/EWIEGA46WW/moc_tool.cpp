/****************************************************************************
** Meta object code from reading C++ file 'tool.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../Transcriptor/tool.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tool.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Tool_t {
    QByteArrayData data[26];
    char stringdata0[564];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Tool_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Tool_t qt_meta_stringdata_Tool = {
    {
QT_MOC_LITERAL(0, 0, 4), // "Tool"
QT_MOC_LITERAL(1, 5, 22), // "handleMediaPlayerError"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 27), // "createKeyboardShortcutGuide"
QT_MOC_LITERAL(4, 57, 10), // "changeFont"
QT_MOC_LITERAL(5, 68, 14), // "changeFontSize"
QT_MOC_LITERAL(6, 83, 6), // "change"
QT_MOC_LITERAL(7, 90, 23), // "transliterationSelected"
QT_MOC_LITERAL(8, 114, 8), // "QAction*"
QT_MOC_LITERAL(9, 123, 6), // "action"
QT_MOC_LITERAL(10, 130, 43), // "on_Upload_and_generate_Transc..."
QT_MOC_LITERAL(11, 174, 24), // "on_btn_translate_clicked"
QT_MOC_LITERAL(12, 199, 34), // "on_editor_openTranscript_trig..."
QT_MOC_LITERAL(13, 234, 20), // "on_add_video_clicked"
QT_MOC_LITERAL(14, 255, 26), // "on_open_transcript_clicked"
QT_MOC_LITERAL(15, 282, 25), // "on_new_transcript_clicked"
QT_MOC_LITERAL(16, 308, 26), // "on_save_transcript_clicked"
QT_MOC_LITERAL(17, 335, 29), // "on_save_as_transcript_clicked"
QT_MOC_LITERAL(18, 365, 29), // "on_load_a_custom_dict_clicked"
QT_MOC_LITERAL(19, 395, 18), // "on_get_PDF_clicked"
QT_MOC_LITERAL(20, 414, 26), // "on_decreseFontSize_clicked"
QT_MOC_LITERAL(21, 441, 27), // "on_increaseFontSize_clicked"
QT_MOC_LITERAL(22, 469, 27), // "on_toggleWordEditor_clicked"
QT_MOC_LITERAL(23, 497, 29), // "on_keyboard_shortcuts_clicked"
QT_MOC_LITERAL(24, 527, 34), // "on_fontComboBox_currentFontCh..."
QT_MOC_LITERAL(25, 562, 1) // "f"

    },
    "Tool\0handleMediaPlayerError\0\0"
    "createKeyboardShortcutGuide\0changeFont\0"
    "changeFontSize\0change\0transliterationSelected\0"
    "QAction*\0action\0"
    "on_Upload_and_generate_Transcript_triggered\0"
    "on_btn_translate_clicked\0"
    "on_editor_openTranscript_triggered\0"
    "on_add_video_clicked\0on_open_transcript_clicked\0"
    "on_new_transcript_clicked\0"
    "on_save_transcript_clicked\0"
    "on_save_as_transcript_clicked\0"
    "on_load_a_custom_dict_clicked\0"
    "on_get_PDF_clicked\0on_decreseFontSize_clicked\0"
    "on_increaseFontSize_clicked\0"
    "on_toggleWordEditor_clicked\0"
    "on_keyboard_shortcuts_clicked\0"
    "on_fontComboBox_currentFontChanged\0f"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Tool[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x08 /* Private */,
       3,    0,  115,    2, 0x08 /* Private */,
       4,    0,  116,    2, 0x08 /* Private */,
       5,    1,  117,    2, 0x08 /* Private */,
       7,    1,  120,    2, 0x08 /* Private */,
      10,    0,  123,    2, 0x08 /* Private */,
      11,    0,  124,    2, 0x08 /* Private */,
      12,    0,  125,    2, 0x08 /* Private */,
      13,    0,  126,    2, 0x08 /* Private */,
      14,    0,  127,    2, 0x08 /* Private */,
      15,    0,  128,    2, 0x08 /* Private */,
      16,    0,  129,    2, 0x08 /* Private */,
      17,    0,  130,    2, 0x08 /* Private */,
      18,    0,  131,    2, 0x08 /* Private */,
      19,    0,  132,    2, 0x08 /* Private */,
      20,    0,  133,    2, 0x08 /* Private */,
      21,    0,  134,    2, 0x08 /* Private */,
      22,    0,  135,    2, 0x08 /* Private */,
      23,    0,  136,    2, 0x08 /* Private */,
      24,    1,  137,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QFont,   25,

       0        // eod
};

void Tool::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Tool *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->handleMediaPlayerError(); break;
        case 1: _t->createKeyboardShortcutGuide(); break;
        case 2: _t->changeFont(); break;
        case 3: _t->changeFontSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->transliterationSelected((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 5: _t->on_Upload_and_generate_Transcript_triggered(); break;
        case 6: _t->on_btn_translate_clicked(); break;
        case 7: _t->on_editor_openTranscript_triggered(); break;
        case 8: _t->on_add_video_clicked(); break;
        case 9: _t->on_open_transcript_clicked(); break;
        case 10: _t->on_new_transcript_clicked(); break;
        case 11: _t->on_save_transcript_clicked(); break;
        case 12: _t->on_save_as_transcript_clicked(); break;
        case 13: _t->on_load_a_custom_dict_clicked(); break;
        case 14: _t->on_get_PDF_clicked(); break;
        case 15: _t->on_decreseFontSize_clicked(); break;
        case 16: _t->on_increaseFontSize_clicked(); break;
        case 17: _t->on_toggleWordEditor_clicked(); break;
        case 18: _t->on_keyboard_shortcuts_clicked(); break;
        case 19: _t->on_fontComboBox_currentFontChanged((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Tool::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_Tool.data,
    qt_meta_data_Tool,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Tool::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Tool::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Tool.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Tool::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
